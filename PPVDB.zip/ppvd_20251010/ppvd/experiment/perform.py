#! /usr/bin/python3

import queue
import os
import random
from threading import Thread
import threading
import math
from formatToTable import format_to_table

class Worker (Thread):
    def __init__(self, threadId, func, args = ()):
        Thread.__init__(self)
        self.threadId = threadId
        self.func = func
        self.args = args

    def run(self):
        self.func(self.threadId, *self.args)

queue_lock = threading.Lock()
work_queue = queue.Queue()
threads = []

def thread_main_func(threadId):
    while True:
        cmd = None
        queue_lock.acquire()
        if not work_queue.empty():
            cmd = work_queue.get()
        queue_lock.release()
        if cmd is None:
            break
        print(f'[{threadId}] running {cmd}')
        os.system(cmd)
    print(f'[{threadId}] thread exit')

def gen_dataset_file(n: int):
    num_len = 4
    filename = f'n{n}-byte{num_len}.json'
    relative_path = f'../dataset/{filename}'
    if not os.path.isfile(relative_path):
        os.system(f'../dataset/genDataset.py --n {n} --byte {num_len} --out {relative_path}')
    return relative_path

def generate_cmd_list(n: int, round: int, tag = ""):
    dataset_path = gen_dataset_file(n)
    cmd_list = []
    for i in range(1, round+1):
        output_filename = f'{n}-{i}-{tag}.txt'
        output_path = f'./output/{output_filename}'
        cmd = f'../build/mainExe {dataset_path} > {output_path}'
        cmd_list.append(cmd)
    return cmd_list

def main1():
    thread_num = 10
    round = 3
    orders = [2*i for i in range(4, 11)]
    n_arr = [2 ** i for i in orders]
    cmd_list = []
    for i in range(len(n_arr)):
        cmd_list += generate_cmd_list(n_arr[i], round, f'2order{orders[i]}')
    random.shuffle(cmd_list)
    for cmd in cmd_list:
        work_queue.put(cmd)
    
    print (f'thread_num = {thread_num}')
    for i in range(thread_num):
        t = Worker(i, thread_main_func)
        t.start()
        threads.append(t)
    
    for t in threads:
        t.join()


def main():
    thread_num = 10  # 线程数
    round = 3        # 每个数据集的重复实验次数
    
    # 直接指定已有的数据集文件路径（无需动态生成）
    dataset_files = [
        "../dataset/n256-byte4.json",     # 2^8
        "../dataset/n1024-byte4.json",    # 2^10
        "../dataset/n4096-byte4.json",    # 2^12
        "../dataset/n16384-byte4.json",   # 2^14
        "../dataset/n65536-byte4.json",   # 2^16
        "../dataset/n262144-byte4.json",  # 2^18
        "../dataset/n1048576-byte4.json"  # 2^20
    ]
    
    cmd_list = []
    for dataset_path in dataset_files:
        # 从文件名提取 n 和 order（用于输出文件命名）
        filename = os.path.basename(dataset_path)  # 如 "n256-byte4.json"
        n = int(filename.split('-')[0][1:])       # 提取 256
        order = int(math.log2(n))                 # 计算 order=8
        
        # 生成 round 条命令
        for i in range(1, round + 1):
            output_filename = f'{n}-{i}-2order{order}.txt'
            output_path = f'./output/{output_filename}'
            cmd = f'../build/mainExe {dataset_path} > {output_path}'
            cmd_list.append(cmd)
    
    # 打乱命令顺序（可选）
    random.shuffle(cmd_list)
    
    # 将命令加入队列并启动线程
    for cmd in cmd_list:
        work_queue.put(cmd)
    
    print(f'thread_num = {thread_num}')
    for i in range(thread_num):
        t = Worker(i, thread_main_func)
        t.start()
        threads.append(t)
    
    for t in threads:
        t.join()

if __name__ == '__main__':
    main()
    format_to_table()
    